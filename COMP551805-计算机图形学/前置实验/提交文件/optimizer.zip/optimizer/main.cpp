#include <memory>                            // 用于智能指针
#include <spdlog/spdlog.h>                   // spdlog的主要头文件
#include <spdlog/sinks/stdout_color_sinks.h> // 用于将带颜色的日志输出到控制台
#include <spdlog/sinks/basic_file_sink.h>    // 用于将日志输出到文件
#include <Eigen/Core>                        // Eigen核心功能
#include <Eigen/Dense>                       // 包括了Eigen的密集矩阵和向量的定义及其操作

int main() 
{
    /*设置spdlog日志记录器并使用自定义格式*/
    // 创建一个控制台日志sink
    auto console_sink = std::make_shared<spdlog::sinks::stdout_color_sink_mt>();  
    // 创建一个文件日志sink
    auto file_sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>("optimizer.log", true);  
    // 创建一个日志记录器并添加sinks
    auto logger = std::make_shared<spdlog::logger>("optimizer", spdlog::sinks_init_list{console_sink, file_sink});  
    // 注册日志记录器
    spdlog::register_logger(logger);  
    // 设置日志记录器的级别为debug
    logger->set_level(spdlog::level::debug);  
    // 设置输出格式
    logger->set_pattern("[%n] [%l] %v");  

    using Eigen::Vector2d;   // 使用Eigen的2维向量

    Vector2d x(520, 279);    // 设置初始点
                             //可以拿Vector2d x(138, 1620)验证
    Vector2d x_prev;         // 再一次牛顿下降迭代中，用于存储前一个点
    Vector2d x_next;         // 用于存储下一个点
    Vector2d x_delta;        // 用于存储两个连续点之间的差异

    double lambda = 0.5;     // 步长
    double delta = 0.01;     // 收敛的阈值

    logger->debug("({}, {})", x[0], x[1]);               // 先在日志中输出最开始的点

    do {
        x_prev = x;                                      // 记录下当前点的点
        x = x * 0.5;                                     // 按照牛顿下降法迭代点，公式推导详见说明文档
        x_next = x;                                      // 记录下更新后的点
        x_delta = x_prev - x_next;                       // 计算两个连续点之间的差异
        if (x_delta.norm() <= delta) {break;}            // 在写入日志之前检查条件是否符合
        logger->debug("({}, {})", x_next[0], x_next[1]); // 在日志中输出迭代后的点
    } while (true);
  
    logger->info("{}", x_prev.norm()*x_prev.norm());     // 记录最终点的函数值，也就是范数平方

    return 0;
}
